#!/usr/bin/python

l1 = [1,2,3,4,5]
print l1 , "list l1 printed"
l1.extend([6,7,8])
print l1, "list l2 printed "
l1.append([9,10,11,12])
print l1, "list l2 printed "
print l1[8][2]
l1.append([1,0,56,76])
print l1, "list l2 printed "
l1.insert(1,3)
print l1[1] , "index of 1 is 3"
l1.append(340)
print l1, "list with 340 printed "
l1.insert(2,'three')
print l1 , "string is inserted in index of 3"
l1.insert(13,'thirteen')
print l1 , "string is inserted in index of 13"
l1.extend('hai')
print l1 , "string is inserted in index of 14 15 16"
print l1[15]
l1.append('naveen')
print l1 , "inserted naveen as string"
