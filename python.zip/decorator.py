#!/usr/bin/python
import time
#def time_it(func):
#    def wrapper(*args,**kwargs):
#        result = func(*args,**kwargs)
#@time_it
#def fun_square(num):
#   # start_time = time.time()
#    result = []
#    for i in num:
#        result.append(i*i)
#    #end_time = time.time()
#    #print "calculated time taken " , str((end_time-start_time)*1000)
#    return result
#
#def fun_cube(num):
#    #t1 = time.time()
#    result = []
#    for i in num:
#        result.append(i*i*i)
#    #t2 = time.time()
#    #print "calculated time taken " , str((t2-t1)*1000)
#    return result
#
#array = range(1,500)
#fun_square(array)
#fun_cube(array)


def time_it(func):
    def wrapper(*args,**kwargs):
        t1 = time.time()
        result = func(*args,**kwargs)
        t2 = time.time()
        print "calculated time taken " , str((t2-t1))
        return result
    return wrapper

@time_it
def fun_square(num):
    result = []
    time.sleep(3)
    for i in num:
        result.append(i*i)
    return result

@time_it
def fun_cube(num):
    result = []
    time.sleep(3)
    for i in num:
        result.append(i*i*i)
    return result


array = range(1,500)
fun_square(array)
fun_cube(array)

