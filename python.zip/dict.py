#!/usr/bin/python
dict1 = {'1':'one','2':'two','3':'three'}
print dict1
d1 = dict1
d1.update['2'] = 'four'
print d1

