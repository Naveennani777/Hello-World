#!/usr/bin/python
"""
# for debugging:
MSG_NAMES = {
    MSG_DISCONNECT: 'disconnect',
    MSG_IGNORE: 'ignore',
    MSG_UNIMPLEMENTED: 'unimplemented',
    MSG_DEBUG: 'debug',
    MSG_SERVICE_REQUEST: 'service-request',
    MSG_SERVICE_ACCEPT: 'service-accept',
    MSG_KEXINIT: 'kexinit',
    MSG_NEWKEYS: 'newkeys',
    30: 'kex30',
    31: 'kex31',
    32: 'kex32',
    33: 'kex33',
    34: 'kex34',
    40: 'kex40',
    41: 'kex41',
    MSG_USERAUTH_REQUEST: 'userauth-request',
    MSG_USERAUTH_FAILURE: 'userauth-failure',
    MSG_USERAUTH_SUCCESS: 'userauth-success',
    MSG_USERAUTH_BANNER: 'userauth--banner',
    MSG_USERAUTH_PK_OK: 'userauth-60(pk-ok/info-request)',
    MSG_USERAUTH_INFO_RESPONSE: 'userauth-info-response',
    MSG_GLOBAL_REQUEST: 'global-request',
    MSG_REQUEST_SUCCESS: 'request-success',
    MSG_REQUEST_FAILURE: 'request-failure',
}

print MSG_NAMES
print MSG_NAMES[30]
print MSG_NAMES[MSG_KEXINIT]
dict1 = {'MSG_DISCONNECT':'disconnect',    'MSG_IGNORE': 'ignore',
    'MSG_UNIMPLEMENTED': 'unimplemented',
    'MSG_DEBUG': 'debug'}
print dict1.keys['MSG_DISCONNECT']
"""
elements = {"Li": {"full_name":"Lithium", "num":"12", "type":"Alkali Metal"}}
print elements["Li"]
