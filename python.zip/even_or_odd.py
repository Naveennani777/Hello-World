n=13
while n > 1: n -= 2 #slow way of modulus.
print "eovdedn"[n::2]
