#!/usr/bin/python
import re,commands,os,sys
fh = open("a.txt" , 'w')
a = commands.getoutput("ls -lrt")
print >> fh, a
#fh.read()
#print fh.readlines(3)
'''f1 = a.join("-")
print f1
print a.readlines(3)
'''
sys.stdout=open("test11.txt","w")
print ("hello")
sys.stdout.close()
