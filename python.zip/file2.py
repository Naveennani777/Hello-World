#!/usr/bin/python
"""try:
    retcode = call("mycmd" + " myarg", shell=True)
    if retcode < 0:
        print >>sys.stderr, "Child was terminated by signal", -retcode
    else:
        print >>sys.stderr, "Child returned", retcode
"""
str1 = raw_input("Enter a string: ")     
    i = len(str1)
    rev = ""
    while i != 0:
        rev = rev + string[i-1]
        i = i - 1
    return rev
reverse(str1)
