#!/usr/bin/python
import commands
fh = commands.getoutput('ls -lrt')
print >> fh , 'testfile.txt'
