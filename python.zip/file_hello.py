#!/usr/bin/python

fh = open("hello.txt", "r+") 
fh.write("Put the text you want to add here\\n") 
fh.write("and more lines if need be.\\n") 
print fh.readlines(1)
fh.close() 
