#!/usr/bin/python

file1 = open("testfile.txt", 'r+')
file1.write("Hai this is naveen nani")
file1.write("Come early and leave early")
file1.write("A friend inn need is friend indeed")
#file.open("testfile.txt", 'r')
print file1.readlines()
print file1.readline(3)


