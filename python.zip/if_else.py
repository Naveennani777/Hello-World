#!/usr/bin/python
#var = 200
var = int(input("Enter an Integer: "))
if var < 150:
    print var , " Entered integer is less than 150"
    if var == 100:
        print var, " is equal to 100"
    elif var == 50:
        print var," is not equal to 150"
    elif var == 100:
        print var, " is equal to 100"
else:
    print var, " is greater than 150"
    
