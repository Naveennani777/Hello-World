#!/usr/bin/python
from datetime import datetime as dt
l1=[1,2,3,4,5,6,7,8,9,10]
l2 = len(l1)
print "length of l1 printed: ", l2
l3 = [i for i in l1 if i%2 == 0 ]
print l3
l4 = (i for i in l1 if i%2 == 0 )
print l4
for i in l1:
    if i%2 == 0:
        print i, "given number is even"
    else:
        print "number is not even"
print dt.today
