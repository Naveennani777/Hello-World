#!/usr/bin/python
a = [x*5 for x in range(2,10,2)]
print a
