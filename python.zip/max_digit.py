#!/usr/bin/python
p = int(input("Enter a integer1: "))
q = int(input("Enter a integer2: "))
r = int(input("Enter a integer3: "))
if p > q:
    print p , " is greater"
elif q > r:
    print q , " is greater"
elif p > r:
    print r , " is greater"
else:
    print "Entered a invalid number"
