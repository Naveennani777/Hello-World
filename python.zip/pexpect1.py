#!/usr/bin/python

import pexpect
mydic = {'1':'one','2':'two','3':'three'}
mydic['1'] ='one'
for key in mydic.keys():
  print "the key name is " + key + " and its value is " + mydic[key]

host_list = open('/home/spanidea/naveen/python/ip_addresses.txt', 'r')
for line in host_list:
    host = line.split()[0]
print "start configured on host" , host
try:
       print(("Successfully ran the test function on host "), (host))
except:
       print(("Test function failed on host "), (host))


class Openstack(object):
    def __init__(self):
        self.c=variable
    def connectNode(self, hostip,uname,pword):
        login_command = 'ssh ' + hostip + ' -l ' + uname
        print login_command
        spawn_id = pexpect.spawn(login_command)
        spawn_id.timeout = 300
        spawn_id.setecho(True)
        i = spawn_id.expect([pexpect.TIMEOUT, 'assword:', pexpect.EOF])
        if i == 0:
                die(spawn_id, 'ERROR!\nSSH timed out. Here is what SSH said:')
                return 0
        elif i == 1:
                spawn_id.sendline(pword)
                spawn_id.expect('>')
                return spawn_id
        elif i == 2:
                die(spawn_id, 'ERROR!\nSSH timed out. Here is what SSH said:')
                return 0






