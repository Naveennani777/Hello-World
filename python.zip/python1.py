#!/usr/bin/python

import re
import os
import pexpect
import io
import sys
import time
value="fdbicbkv jdincl szxfqE10.1.1.2MCKJSDVC10.1.11.3OWDMVK V20.1.1.4  N DD SNJV BSDD CJSCCCS;WUCCBNNHCLW 10.1.1.2VDCUDGDVUDDHVCD"
regexp="\w+\s+.*([0-9]{2}\.[0-9]{1}\.[0-9]{1}\.[0-9]{1}).*([0-9]{2}\.[0-9]{1}\.[0-9]{1}\.[0-9]{1}).*"
if re.search(regexp,value):
    out = re.search(regexp,value)
    print "matched regular expression with 2nd IP Address: ",out.group(2)
    print "IP Address: ",out.group(1)
else:
    print "NOt a valid match"


def cmd_output():
    #out1 = os.system('ping google.com -c 5')
    out2 = ["connect: Network is unreachable" ,"ping: unknown host google.com"]
    print out2[0]
    print out2[1]
    os.system('rm -r nani')
    cmd = os.system
    cmd('pwd')
    cmd('ls -lrt')
   # return out1

cmd_output()
"""
file1 = os.system('pwd')
file2 = "/home/spanidea/naveen/python/re_org.txt"
print file1
print file2
file3 = open("file2" , "r")
f4 = file3.read()
print f4
"""
t1 = time.clock()
print "******"
print sys.argv
print dir(os)
print dir(pexpect)
#print help(os)
t2 = time.clock()
clock1 = t2-t1
print clock1
