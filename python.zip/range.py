#!/usr/bin/python
l1=range(10)
print l1
l2 = range(10,0,-1)
print l2
l3 = l1+l2
print l3
print l3[::-1],"l3 in reverse"
print l2[::-1], "l2 in reverse"
print l1[::-1],"l1 in reverse"
a = [1,2,3]
print len(a)
#a[len(a):] = [6]
print a[3:], "slicing "
print a
