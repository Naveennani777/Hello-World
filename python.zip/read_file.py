#!/usr/bin/python

import re
import time
import copy
import os


os.mkdir('nav_nani')
os.chdir('nav_nani')
os.system('touch nav')
exit
s = time.sleep(3)

file1= """
A    Z    1000
B    Y    3000
c    X    5000
"""
f34= file1
#f32 = file1.readlines()
f4 = f34.split('.')
print file1 , "file1 printed"
print f4 , "f4 printed"
#f4 = f3.readlines()
regexp = ".*B.*(\d).*"
f5 = re.search(f4,regexp)
print f5.group(1)
"""
d = "dictionary"
print "create a d Update d remove elements from d and delete all elements in one shot from d "
dict1 = {'1':'one','2':'two','3':'three','4':'four'}
dict2 = {'5':'five','6':'six','7':'seven','8':'eight'}
dict1.update(dict2)
print dict1
dict1['9']='nine'
dict1['10']='ten'
print dict1
del dict1['4']
print dict1
time.sleep(2)
d3 = str(dict1)
del dict1['1']
print dict1, "dict1 printed"
dict5 = dict1
print dict2 , "dict2 printed"
dict3 = copy.copy(dict5)
s
dict4 = copy.deepcopy(dict5)
s
print id(dict1) , "dict1 id printed"
s
print id(dict3) , "id printed for dict3"
s
print id(dict4) , "id printed for dict4"
time.sleep(2)
del dict5 # removed dict5 d
print id(dict3)
s
print id(dict4)
s
dict1.clear() #delete entire elements from dict
print dict1
del dict1   # delete dict1 dictionary
try:
    print dict1
except:
    print "dict1 is not defined"

"""


