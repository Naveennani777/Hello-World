#!/usr/bin/python
import re
string= "192.168.45.1    1      FULL/DR    00:00:36     10.0.0.1    Ethernet0"
#regexp = '[\d\.]+\s+\d\s+(FULL)\/\w+.*'
regexp = '.*(FULL).*(\d{2}\.\d+\.\d+\.\d).*'
match = re.search(regexp,string)
print match.group(0), ":whole matched string"
print match.group(1), ":Status match"
print match.group(2), ":IP address match"
#status = 'FULL'
#if status == FULL:
#    print "neighborship formed"
#else:
#    print "Neighborship not formed"
