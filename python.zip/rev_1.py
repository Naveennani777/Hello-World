#!/usr/bin/python

def reverse(text):
    rev = ''
    for i in range(len(text), 0, -1):
        rev += text[i-1]
    return rev

#p = reverse('string')
#print p
