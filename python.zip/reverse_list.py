#!/usr/bin/python
#l = [1,2,3,4,5]
#i = len(l)
#while i < len(l)/2:
#    l(i),l(len(l)-1-i) = l(len(l)-1-i), l(i)
#print l
l = [1,2,3,4,5]
l1 = len(l)
for i in range(len(l)/2):
    l(i),l(l1-i-1) = l(l1-1-i),l(i)
print l
