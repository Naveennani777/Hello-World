#!/usr/bin/python
	
nums = {n**2 for n in range(10)} # Set is an unordered elements}
#{0, 1, 64, 4, 36, 9, 16, 49, 81, 25}
print "set is unordered elements" , (nums)
nums1 = [n**2 for n in range(10)] # List is ordered elements
print "List is ordered elements" ,(nums1)
print "#list comprehension python tutorial point"
l = [1,2,3,4,5]
l1 = len(l)/2
for i in range(l1)/2:
    

