#!/usr/bin/python
set = {1,1,1,1,2,2,3,3,3,4,4,2,3,4}
print set
