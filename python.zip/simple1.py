#!/usr/bin/python

import Openstack
print "Welcome to span idea"
