#!/usr/bin/python
import commands,subprocess,sys
a=commands.getoutput('ls -lrt')
fh = open('xft8.txt', 'w')
fh.write(a)
fh.close
b,c = commands.getstatusoutput('pwd')
fh1 = open("pwd.txt","w")
print b, "status of pwd command"
if b != 0:
    print "command not executed"
else:
    print "command executed successfully"
fh1.write(c)
fh1.close
l = [1,2,3,4,5,6,7,8,9]
print l , "list printed"
print "program for printing numbers less than 5"
for i in range(1,10):
    if i < 5:
        print i
print "program for printing numbers greater than 5"
for i in range(1,10):
    if i > 5 :
        a = []
        a.append(i)
        print a
output = subprocess.check_output(['/home/spanidea/naveen/python', 'python append.py'])
with open('outfile123.txt', 'wb') as outfile:
    outfile.write(output)
